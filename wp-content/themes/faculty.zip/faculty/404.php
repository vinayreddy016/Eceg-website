<?php
/**
 * @package WordPress
 * @subpackage themename
 */

get_header(); ?>


<div class="fac-page home">
		<div id="inside">
			<div class="vc_responsive wpb_row vc_row-fluid">
				<h1 class="text-center"><?php _e( 'This is somewhat embarrassing, isn&rsquo;t it?', 'faculty' ); ?></h1>	
			</div>

			<div class="vc_responsive wpb_row vc_row-fluid">
				
				<h1 class="fac-big-title fac-title text-center">404</h1>
				
			</div>
		</div>	
	</div>
	<div id="overlay"></div>

<?php get_footer(); ?>