<?php
/**
 * @package WordPress
 * @subpackage Faculty
 */
?>
			</div>
        </div>
        
        <div id="facwpfooter">
        	<?php wp_footer(); ?>
        </div>
    </body>
</html>
